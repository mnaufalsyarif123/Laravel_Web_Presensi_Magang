<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PresensiController extends Controller
{
    public function index()
    {
        // Periksa apakah user sudah check-in hari ini berdasarkan session
        $hasCheckedIn = session('hasCheckedIn', false);
        $presensiUuid = session('presensi_uuid', null);

        return view('user.presensi', compact('hasCheckedIn', 'presensiUuid'));
    }

    public function store(Request $request)
    {

// Validasi input foto kehadiran
    $request->validate([
        'foto_kehadiran' => 'required|string|max:65535', // LONGTEXT mendukung hingga 4GB
    ]);

        // Simpan data check-in ke tabel `presensi`
        $uuid = \Str::uuid(); // Generate UUID unik
        $tanggal = Carbon::now()->toDateString();
        $waktuCheckIn = Carbon::now()->toTimeString();

        DB::table('presensi')->insert([
            'user_uuid' => 'some-user-uuid', // Gantilah dengan UUID pengguna yang seharusnya
            'tanggal' => $tanggal,
            'waktu_check_in' => $waktuCheckIn,
            'foto_bukti_check_in' => $request->foto_kehadiran,
            'waktu_check_out' => null,
            'keterangan_harian' => null,
            'status' => 'Masuk',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Simpan status check-in di session
        session(['hasCheckedIn' => true, 'presensi_uuid' => $uuid]);

        return redirect()->back()->with('success', 'Check-in berhasil!');
    }

    public function checkOut(Request $request, $uuid)
    {
        // Validasi input deskripsi pekerjaan
        $request->validate([
            'deskripsi_pekerjaan' => 'required|string',
        ]);

        // Update data check-out di tabel `presensi`
        $waktuCheckOut = Carbon::now()->toTimeString();

        DB::table('presensi')
            ->where('user_uuid', 'some-user-uuid') // Gantilah dengan UUID pengguna yang seharusnya
            ->where('uuid', $uuid)
            ->update([
                'waktu_check_out' => $waktuCheckOut,
                'keterangan_harian' => $request->deskripsi_pekerjaan,
                'status' => 'Keluar',
                'updated_at' => now(),
            ]);

        // Hapus session check-in
        session()->forget(['hasCheckedIn', 'presensi_uuid']);

        return redirect()->back()->with('success', 'Check-out berhasil!');
    }
}
